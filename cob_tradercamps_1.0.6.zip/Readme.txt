
This is a stand-alone version of a mod that is included in the Conquest of Blocks server pack.

==========================================================================================
"CONQUEST OF BLOCKS" - Multiplayer server for Vintage Story. SERVER IP 135.125.3.191:33511
==========================================================================================

Website: www.vintagestory.online
Discord: discord.io/cobcom | discord.gg/tXRcKXf

Mod description:
In the vanilla game, traders can mostly be found as lone wolves somewhere in the wild. 
With this mod, traders will more often be together in small camps. Single traders will 
still be available, but less often.


This version of the mod is free to use on any multiplayer server.
Your clients do not need to download this mod. It's server side only.


HOW TO MODIFY:
==============
The mod will generate a "TraderCamps.json" in your ModConfig folder.

"TraderCampSetup":

1 (medium density, claimed)
2 (medium density, unclaimed)
3 (high density, claimed)
4 (high density, unclaimed)
5 (low density, claimed)
6 (low density, unclaimed)