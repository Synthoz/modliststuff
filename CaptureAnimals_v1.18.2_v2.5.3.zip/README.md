# CaptureAnimals

https://www.vintagestory.at/forums/topic/2247-capture-animals/
